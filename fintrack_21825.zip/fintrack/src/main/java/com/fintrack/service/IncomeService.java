package com.fintrack.service;

import com.fintrack.model.Income;
import com.fintrack.model.User;
import com.fintrack.repository.IncomeRepository;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class IncomeService {
    private final IncomeRepository incomeRepository;

    public IncomeService(IncomeRepository incomeRepository) {
        this.incomeRepository = incomeRepository;
    }

    public void saveIncome(Income income) {
        incomeRepository.save(income);
    }

    public List<Income> getIncomesByUser(User user) {
        return incomeRepository.findByUser(user);
    }

    public void deleteIncome(Long id) {
        incomeRepository.deleteById(id);
    }
}
