package com.fintrack.controller;

import com.fintrack.model.Category;
import com.fintrack.model.Income;
import com.fintrack.model.User;
import com.fintrack.service.CategoryService;
import com.fintrack.service.IncomeService;
import com.fintrack.service.UserService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.security.Principal;
import java.util.List;

@Controller
@RequestMapping("/income")
public class IncomeController {

    private final IncomeService incomeService;
    private final CategoryService categoryService;
    private final UserService userService;

    public IncomeController(IncomeService incomeService, CategoryService categoryService, UserService userService) {
        this.incomeService = incomeService;
        this.categoryService = categoryService;
        this.userService = userService;
    }

    @GetMapping
    public String incomePage(Model model, Principal principal) {
        User user = userService.findByEmail(principal.getName());
        List<Income> incomes = incomeService.getIncomesByUser(user);
        List<Category> categories = categoryService.getCategoriesByUser(user);

        model.addAttribute("incomes", incomes);
        model.addAttribute("categories", categories);
        model.addAttribute("income", new Income());
        return "income"; // income.html
    }

    @PostMapping("/add")
    public String addIncome(@ModelAttribute Income income, @RequestParam Long categoryId, Principal principal) {
        User user = userService.findByEmail(principal.getName());
        Category category = categoryService.getCategoryById(categoryId);

        income.setUser(user);
        income.setCategory(category);
        incomeService.saveIncome(income);

        return "redirect:/income";
    }

    @GetMapping("/delete/{id}")
    public String deleteIncome(@PathVariable Long id) {
        incomeService.deleteIncome(id);
        return "redirect:/income";
    }
}
