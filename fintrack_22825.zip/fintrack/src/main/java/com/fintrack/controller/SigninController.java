// package com.fintrack.controller;

// import com.fintrack.model.User;
// import com.fintrack.service.UserService;
// import jakarta.servlet.http.HttpSession;
// import org.springframework.beans.factory.annotation.Autowired;
// import org.springframework.stereotype.Controller;
// import org.springframework.ui.Model;
// import org.springframework.web.bind.annotation.*;

// @Controller
// public class SigninController {

// @Autowired
// private UserService userService;

// @GetMapping("/signin")
// public String showLoginForm(Model model, @RequestParam(value = "error",
// required = false) String error) {
// model.addAttribute("user", new User());

// if (error != null) {
// model.addAttribute("error", "Invalid email or password!");
// }

// return "signin";
// }

// @PostMapping("/signin")
// public String processLogin(@ModelAttribute("user") User user, HttpSession
// session, Model model) {
// User dbUser = userService.findByEmail(user.getEmail());

// if (dbUser != null && dbUser.getPassword().equals(user.getPassword())) {
// // Save user in session
// session.setAttribute("loggedInUser", dbUser);
// return "redirect:/dashboard";
// } else {
// // Redirect with error
// return "redirect:/signin?error";
// }
// }
// }

// package com.fintrack.controller;

// import com.fintrack.model.User;
// import com.fintrack.service.UserService;
// import jakarta.servlet.http.HttpSession;
// import org.springframework.beans.factory.annotation.Autowired;
// import org.springframework.stereotype.Controller;
// import org.springframework.ui.Model;
// import org.springframework.web.bind.annotation.*;

// @Controller
// public class SigninController {

// @Autowired
// private UserService userService;

// // Show Signin Page
// @GetMapping("/signin")
// public String showSigninForm(Model model, @RequestParam(value = "error",
// required = false) String error) {
// model.addAttribute("user", new User());
// if (error != null) {
// model.addAttribute("error", "Invalid email or password!");
// }
// return "signin"; // Return signin.html
// }

// // Handle Login Form Submission
// @PostMapping("/signin")
// public String processLogin(@ModelAttribute("user") User user, HttpSession
// session, Model model) {
// // Get user from DB using email
// User dbUser = userService.findByEmail(user.getEmail().trim());

// System.out.println("=== Login Attempt ===");
// System.out.println("Entered Email: " + user.getEmail());
// System.out.println("Entered Password: " + user.getPassword());
// if (dbUser != null) {
// System.out.println("DB User Found: " + dbUser.getEmail());
// System.out.println("DB Password: " + dbUser.getPassword());
// } else {
// System.out.println("DB User Not Found");
// }

// // Compare email and password (trimmed)
// if (dbUser != null &&
// dbUser.getPassword().trim().equals(user.getPassword().trim())) {
// session.setAttribute("loggedInUser", dbUser);
// return "redirect:/dashboard";
// } else {
// return "redirect:/signin?error";
// }
// }
// }

// package com.fintrack.controller;

// import com.fintrack.model.User;
// import com.fintrack.service.UserService;
// import jakarta.servlet.http.HttpSession;
// import org.springframework.beans.factory.annotation.Autowired;
// import org.springframework.stereotype.Controller;
// import org.springframework.ui.Model;
// import org.springframework.web.bind.annotation.*;

// @Controller
// public class SigninController {

//     @Autowired
//     private UserService userService;

//     @GetMapping("/signin")
//     public String showSigninForm(Model model, @RequestParam(value = "error", required = false) String error) {
//         model.addAttribute("user", new User());
//         if (error != null) {
//             model.addAttribute("error", "Invalid email or password!");
//         }
//         return "signin";
//     }

//     @PostMapping("/signin")
//     public String processLogin(@ModelAttribute("user") User user, HttpSession session) {
//         System.out.println("Login attempt: " + user.getEmail());

//         User dbUser = userService.findByEmail(user.getEmail().trim());

//         if (dbUser != null) {
//             System.out.println("DB Password: " + dbUser.getPassword());
//             System.out.println("Entered Password: " + user.getPassword());

//             if (dbUser.getPassword().trim().equals(user.getPassword().trim())) {
//                 session.setAttribute("loggedInUser", dbUser);
//                 return "redirect:/dashboard";
//             }
//         }

//         return "redirect:/signin?error";
//     }
// }

/*




package com.fintrack.controller;

import jakarta.servlet.http.HttpSession;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
public class SigninController {

    @GetMapping("/signin")
    public String showSigninForm() {
        return "signin"; // signin.html
    }

    @PostMapping("/signin")
    public String processSignin(@RequestParam("email") String email,
            @RequestParam("password") String password,
            HttpSession session,
            Model model) {

        // Default credentials
        String defaultEmail = "sigma@gmail.com";
        String defaultPassword = "sigma123";

        if (email.equals(defaultEmail) && password.equals(defaultPassword)) {
            session.setAttribute("loggedInUser", email);
            return "redirect:/dashboard"; // success
        } else {
            model.addAttribute("error", "Invalid email or password!");
            return "signin"; // stay on login page
        }
    }
}


*/
package com.fintrack.controller;

import com.fintrack.model.User;
import com.fintrack.service.UserService;
import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
public class SigninController {

    @Autowired
    private UserService userService;

    // @GetMapping("/signin")
    // public String showSignInPage(Model model) {
    // return "signin"; // signin.html
    // }

    @GetMapping("/signin")
    public String showSignin(Model model, @RequestParam(value = "error", required = false) String err) {
        model.addAttribute("user", new User());
        if (err != null)
            model.addAttribute("error", err.toString());
        return "signin";
    }

    @PostMapping("/signin")
    public String loginUser(@ModelAttribute("user") User userForm, HttpSession session, Model model) {

        // Lookup user by email
        User user = userService.findByEmail(userForm.getEmail());

        if (user != null && user.getPassword().equals(userForm.getPassword())) {
            // ✅ Valid credentials → store in session
            session.setAttribute("loggedUser", user);

            System.out.println(user.getEmail());
            System.out.println("Redirect abb hoga");

            // Redirect to dashboard
            return "redirect:/dashboard";
        } else {
            // ❌ Invalid credentials → return to login with error
            String errorMsg = "Invalid email or password for email: " + userForm.getEmail();

            // Add error to model to show in UI
            model.addAttribute("error", errorMsg);

            // Print error in console for debugging
            System.out.println(errorMsg);

            return "signin";
        }
    }
}

// sigma@gmail.com