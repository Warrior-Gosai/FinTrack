package com.fintrack.controller;

import com.fintrack.model.Category;
import com.fintrack.model.Income;
import com.fintrack.repository.CategoryRepository;
import com.fintrack.service.IncomeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
@RequestMapping("/income")
public class IncomeController {

    @Autowired
    private IncomeService incomeService;

    @Autowired
    private CategoryRepository categoryRepository;

    // Show Income page with incomes + categories
    @GetMapping
    public String viewIncomePage(Model model) {
        List<Income> incomes = incomeService.getAllIncomes();
        List<Category> categories = categoryRepository.findAll();

        model.addAttribute("incomes", incomes);
        model.addAttribute("categories", categories);
        model.addAttribute("income", new Income());

        return "income"; // loads income.html
    }

    // Add new income
    @PostMapping("/add")
    public String addIncome(@ModelAttribute Income income) {
        incomeService.saveIncome(income);
        return "redirect:/income";
    }

    // Delete income
    @GetMapping("/delete/{id}")
    public String deleteIncome(@PathVariable Long id) {
        incomeService.deleteIncome(id);
        return "redirect:/income";
    }
}
