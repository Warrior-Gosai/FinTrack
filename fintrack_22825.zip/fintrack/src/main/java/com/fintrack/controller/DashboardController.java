package com.fintrack.controller;

import org.springframework.stereotype.Controller;
// import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import jakarta.servlet.http.HttpSession;

/*
*
* @Bean
public UserDetailsService userDetailsService() {
UserDetails user = User.withDefaultPasswordEncoder() // Not for production
.username("testuser") // Your temporary username
.password("testpass") // Your temporary password
.roles("USER")
.build();

return new InMemoryUserDetailsManager(user);
}
*/
@Controller
public class DashboardController {

    @GetMapping("/dashboard")
    public String showDashboard(HttpSession session) {
        // Working Now!!
        // Redirect to signin if not logged in
        if (session.getAttribute("loggedUser") == null) {
            return "redirect:/signin";
        }

        return "dashboard"; // dashboard.html
    }

    // @GetMapping("/dashboard")
    // public String dashboard(HttpSession session, Model model) {
    // Object user = session.getAttribute("loggedUser");

    // if (user == null) {
    // return "redirect:/signin"; // 🔒 block if not logged in
    // }

    // model.addAttribute("user", user);
    // return "dashboard"; // dashboard.html
    // }

    // @GetMapping("/income")
    // public String income() {
    // return "income";
    // }

    @GetMapping("/expense")
    public String expense() {
        return "expense";
    }

    @GetMapping("/category")
    public String category() {
        return "category";
    }

    @GetMapping("/filter")
    public String filter() {
        return "filter";
    }
}
