package com.fintrack.service;

import com.fintrack.model.Category;
import com.fintrack.model.Income;
import com.fintrack.repository.CategoryRepository;
import com.fintrack.repository.IncomeRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class IncomeService {

    @Autowired
    private IncomeRepository incomeRepository;

    @Autowired
    private CategoryRepository categoryRepository;

    // Fetch all incomes
    public List<Income> getAllIncomes() {
        return incomeRepository.findAll();
    }

    // Save income with category
    public void saveIncome(Income income) {
        if (income.getCategory() != null && income.getCategory().getId() != null) {
            Category cat = categoryRepository.findById(income.getCategory().getId())
                    .orElse(null);
            income.setCategory(cat);
        }
        incomeRepository.save(income);
    }

    // Delete income
    public void deleteIncome(Long id) {
        incomeRepository.deleteById(id);
    }
}
