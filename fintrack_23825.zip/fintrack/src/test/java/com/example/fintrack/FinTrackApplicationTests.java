package com.example.fintrack;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FinTrackApplicationTests {

	@Test
	void contextLoads() {
	}

}
